#ifndef	__NND_INCLUDED__
#define	__NND_INCLUDED__

#include "typedef.h"

#endif